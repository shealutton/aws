from __future__ import print_function

import base64
import json
import psycopg2

print('Loading function')


def lambda_handler(event, context):
    #print("Received event: " + json.dumps(event, indent=2))
    # Body:
    # 2017-04-20T10:51:35-05:00,1516685,3821752,7352132,224.41.96.118,ge,499.00
    counter = 0

    conn = psycopg2.connect(host='client.czoejktismoh.us-east-1.rds.amazonaws.com', dbname='client', user='client',
                            password='ganges-9302-Wellness')
    cur = conn.cursor()

    sql = 'INSERT INTO testdata (tradeid, firmid, accountid, clearingfirmid, ip, instrument, quantity, price) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)'
    # Loop, inserting any data we receive
    while True:
        cur.execute(sql, ('2529569', '3333125', '9287656', '181.179.33.197', 'ge', '397.00'))
        conn.commit()


    for record in event['Records']:
        # Kinesis data is base64 encoded so decode here
        payload = base64.b64decode(record['kinesis']['data'])
        payload_items = payload.split(',')
        print("Decoded payload: " + str(counter) + '   ', payload_items)
        counter += 1
    return 'Successfully processed {} records.'.format(len(event['Records']))
